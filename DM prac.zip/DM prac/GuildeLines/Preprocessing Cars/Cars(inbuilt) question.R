# Question-1
# Load the dataset
data("cars")

# Display the structure of the dataset
str(cars)

# Compute the mean, geometric mean, harmonic mean, and median of speed and dist columns
speed_mean <- mean(cars$speed)
print(speed_mean)
speed_gmean <- exp(mean(log(cars$speed)))
print(speed_gmean)
speed_hmean <- length(cars$speed) / sum(1/cars$speed)
print(speed_hmean)
speed_median <- median(cars$speed)
print(speed_median)

dist_mean <- mean(cars$dist)
print(dist_mean)
dist_gmean <- exp(mean(log(cars$dist)))
print(dist_gmean)
dist_hmean <- length(cars$dist) / sum(1/cars$dist)
print(dist_hmean)
dist_median <- median(cars$dist)
print(dist_median)

# Find the unique values of dist column
dist_unique <- unique(cars$dist)
print(dist_unique)

# Find the variance of both the columns
speed_var <- var(cars$speed)
print(speed_var)
dist_var <- var(cars$dist)
print(dist_var)

# Find the IQR of speed column
speed_IQR <- IQR(cars$speed)
print(speed_IQR)

# Create quartiles for dist column
dist_quartiles <- quantile(cars$dist, probs = c(0.25, 0.5, 0.75))
print(dist_quartiles)