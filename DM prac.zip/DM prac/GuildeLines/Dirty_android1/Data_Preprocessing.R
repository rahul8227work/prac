# Question-2
# Load the data set
dirty_android1 <- read.csv("C:/Users/rahul/OneDrive/Desktop/DM prac/Dirty_android1/dirty_data.csv", header=FALSE)
View(dirty_android1)

# Identify the count of NA's in the data frame
na_count <- sum(is.na(dirty_android1))
print(na_count)

# Calculate the number and percentage of observations that are complete
complete_observations <- sum(complete.cases(dirty_android1))
print(complete_observations)
complete_percentage <- complete_observations/nrow(dirty_android1) * 100
print(complete_percentage)

# Find the position of NA values in LCOM3 column
na_index <- which(is.na(dirty_android1$LCOM3))
print(na_index)

# Report the mean values of each column
library(dplyr)

# Select only numeric columns
numeric_cols <- dirty_android1 %>% select_if(is.numeric)

# Calculate the mean of each column
column_means <- colMeans(numeric_cols, na.rm = TRUE)
print(column_means)


# Replace all empty rows with mean values of the column
dirty_android1[is.na(dirty_android1)] <- lapply(dirty_android1, function(x) ifelse(is.na(x), mean(x, na.rm = TRUE), x))
print(dirty_android1[is.na(dirty_android1)])

# Report the mean values of each column after replacing empty rows with mean values
column_means_after_replacement <- colMeans(dirty_android1)
print(column_means_after_replacement)

# Read the dataset again in another data frame variable and omit all the records with NA values
dirty_android1_omitted <- dirty_android1[complete.cases(dirty_android1),]
print(dirty_android1_omitted)

